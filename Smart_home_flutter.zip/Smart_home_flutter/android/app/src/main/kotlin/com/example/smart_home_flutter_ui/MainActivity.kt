package com.example.smart_home_flutter_ui

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
