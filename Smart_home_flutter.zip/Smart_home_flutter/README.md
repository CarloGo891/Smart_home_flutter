# Smart Home Flutter UI

![Smart Home Part](./Smart_Home_Part.jpg)

Smart Home app #UI using #flutter to showcase an ability to control devices at home through Smartphone. On the Home page, you will get all users who can access the app and a list of all room categories which allow users to control devices individually.
There is also a drawer menu present for more accessibility.

# [Watch it on YouTube <a href="https://twitter.com/JamilShahbaj"><img src="https://github.com/shahbajjamil/Social-Meadia-Icons/raw/master/Icons-logos/youtube-circle.png" height="30"></a>](https://youtu.be/TovttAgEmC4)

# [Watch it on Instagram <a href="https://instagram.com/strength_code"><img src="https://github.com/shahbajjamil/Social-Meadia-Icons/raw/master/Icons-logos/instagram-circle.png" height="30"></a>](https://instagram.com/strength_code)

## Project Created by
### Shahbaj Jamil
 #Flutter, #Android Developer, #ios.
 
<a href="https://www.instagram.com/shahbaj_jamil"><img src="https://github.com/shahbajjamil/Social-Meadia-Icons/raw/master/Icons-logos/instagram-circle.png" width="60"></a>   <a href="https://www.facebook.com/shahbaj.jamil"><img src="https://github.com/shahbajjamil/Social-Meadia-Icons/raw/master/Icons-logos/facebook-circle.png" width="60"></a>   <a href="https://twitter.com/JamilShahbaj"><img src="https://github.com/shahbajjamil/Social-Meadia-Icons/raw/master/Icons-logos/twitter-circle.png" width="60"></a>   <a href="https://youtu.be/3_W5BW2aqCQ"><img src="https://github.com/shahbajjamil/Social-Meadia-Icons/raw/master/Icons-logos/youtube-circle.png" width="60"></a>

