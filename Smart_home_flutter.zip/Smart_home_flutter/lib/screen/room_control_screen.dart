import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:smart_home_flutter_ui/constants/app_colors.dart';
import 'package:smart_home_flutter_ui/model/smart_home_model.dart';
import 'package:smart_home_flutter_ui/screen/widgets/device_switch.dart';
import 'package:smart_home_flutter_ui/screen/widgets/glass_morphism.dart';

class RoomControlScreen extends StatefulWidget {
  const RoomControlScreen({super.key, required this.roomData});
  final SmartHomeModel roomData;

  @override
  State<RoomControlScreen> createState() => _RoomControlScreenState();
}

class _RoomControlScreenState extends State<RoomControlScreen> {
  late ScrollController _scrollController; // SCROLL CONTROLLER

  @override
  void initState() {
    super.initState();
    _scrollController = ScrollController(); // INIT SCROLL CONTROLLER
  }

  @override
  void dispose() {
    _scrollController.dispose(); // CLEAN UP CONTROLLER
    super.dispose();
  }

  // FUNCTION PARA MO-SCROLL LEFT
  void _scrollLeft() {
    _scrollController.animateTo(
      _scrollController.offset - 150, // SCROLL LEFT BY 150PX
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  // FUNCTION PARA MO-SCROLL RIGHT
  void _scrollRight() {
    _scrollController.animateTo(
      _scrollController.offset + 150, // SCROLL RIGHT BY 150PX
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    final SmartHomeModel roomData = widget.roomData;
    final Size size = MediaQuery.of(context).size;

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(roomData.roomImage),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: AppColor.fgColor.withOpacity(0.4),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(
                          Icons.arrow_back_ios_new,
                          color: AppColor.white,
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColor.fgColor.withOpacity(0.4),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(
                        Icons.settings,
                        color: AppColor.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            bottomCard(size, roomData),
          ],
        ),
      ),
    );
  }

  Widget bottomCard(Size size, SmartHomeModel roomData) {
    return GlassMorphism(
      child: SizedBox(
        width: double.infinity,
        height: size.height * 0.6,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    roomData.roomName,
                    style: const TextStyle(
                      color: AppColor.white,
                      fontSize: 25,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(
                    height: 30,
                    child: FittedBox(
                      child: CupertinoSwitch(
                        value: roomData.roomStatus,
                        activeTrackColor: AppColor.white,
                        inactiveTrackColor: AppColor.black.withOpacity(.3),
                        thumbColor: AppColor.fgColor,
                        onChanged: (value) {
                          setState(() {
                            roomData.roomStatus = value;
                          });
                        },
                      ),
                    ),
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20, right: 60),
              child: Text.rich(
                TextSpan(
                  text: 'Your ',
                  style: const TextStyle(
                    color: AppColor.white,
                    fontSize: 16,
                  ),
                  children: [
                    TextSpan(text: roomData.roomName),
                    const TextSpan(text: ' is connected with '),
                    TextSpan(text: roomData.devices!.length.toString()),
                    const TextSpan(text: ' and '),
                    TextSpan(
                      text: '${roomData.userAccess} users',
                      style: const TextStyle(
                        decoration: TextDecoration.underline,
                      ),
                    ),
                    const TextSpan(text: ' have access for '),
                    TextSpan(text: roomData.roomName),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(left: 20),
              child: Text(
                roomData.roomTemperature,
                style: const TextStyle(
                  fontSize: 30,
                  color: AppColor.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Divider(
              color: AppColor.white.withOpacity(0.5),
              thickness: 1,
              endIndent: 20,
              indent: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Devices',
                    style: TextStyle(
                      fontSize: 20,
                      color: AppColor.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Row(
                    children: [
                      IconButton(
                        onPressed: _scrollLeft, // SCROLL LEFT BUTTON
                        icon: const Icon(Icons.arrow_back_ios),
                        color: AppColor.white,
                      ),
                      IconButton(
                        onPressed: _scrollRight, // SCROLL RIGHT BUTTON
                        icon: const Icon(Icons.arrow_forward_ios),
                        color: AppColor.white,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            SizedBox(
              height: size.height * 0.22,
              child: ListView.builder(
                controller: _scrollController, // ADD SCROLL CONTROLLER
                itemCount: roomData.devices!.length + 2,
                scrollDirection: Axis.horizontal,
                itemBuilder: (context, index) {
                  if (index == 0 || roomData.devices!.length + 1 == index) {
                    return const SizedBox(width: 10);
                  }
                  final data = roomData.devices![index - 1];
                  return DeviceSwitch(data: data);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
